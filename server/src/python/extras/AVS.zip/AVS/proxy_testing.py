import requests
from bs4 import BeautifulSoup
import time
import random
import os


def proxies():
	file = "proxies.txt"
	# file = input("Your proxies list: ")
	proxies = []
	with open(file, "r") as p:
		proxies = [line.strip() for line in p]
	proxy = random.choice(proxies)
	start = 0
	end = proxy.index(":")
	st = proxy[start:end]
	e = proxy[end+1:]
	global proxie
	proxie = {"http":"{}:{}".format(st, e)}