import requests
from bs4 import BeautifulSoup
import time
import random
import os
import sys
import urllib.request, socket

def proxies():
    file = "proxies.txt"
    proxies = []
    with open(file, "r") as p:
        proxies = [line.strip() for line in p]
    proxy = random.choice(proxies)
    start = 0
    end = proxy.index(":")
    st = proxy[start:end]
    e = proxy[end + 1:]
    global proxie
    proxie = {"https": "{}:{}".format(st, e)}
    print("Got random proxy" + str(proxie['https']))

def check_proxy(pip):
    try:
        proxy_handler = urllib.request.ProxyHandler({'https': pip})
        opener = urllib.request.build_opener(proxy_handler)
        opener.addheaders = [('User-agent', 'Mozilla/5.0')]
        urllib.request.install_opener(opener)
        sock=urllib.request.urlopen('https://www.myip.com/')  # change the url address here
        # print(pip)
    except urllib.error.HTTPError as e:
        return e
    except Exception as detail:
        return detail
    return 0

def get_proxy():
    while True:
        proxies()
        if check_proxy(str(proxie['https'])) == 0:
            print("Found Live Proxy " + str(proxie['https']))
            return

page_no = 1
while True:
    # get_proxy()

    googleTrendsUrl = 'https://google.com'
    response = requests.get(googleTrendsUrl)
    print(str(response))
    if response.status_code == 200:
        g_cookies = response.cookies.get_dict()

    headers = {'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_5)\
                    AppleWebKit/537.36 (KHTML, like Gecko) Cafari/537.36'}

    query = 'inurl:wp-content/%20after:2020-05-02%20inurl:shop&start='

    response1 = requests.get('https://www.google.com/search?&q=' + query + str(page_no), headers = headers,cookies = g_cookies)
    print('Checking Search : ' + 'https://www.google.com/search?&q=' + query + str(page_no))
    page_no = page_no + 1

    soup = BeautifulSoup(response1.text,'html.parser')
    search_results = soup.select('.kCrYT a')

    for link in search_results[:7]:
        url = link.get('href')[7:]
        print(url)
        url2 = url.split('/')
        url3 = url2[0] + '//' + url2[2]
        print(url3)
        with open("GrabbedLinks.txt",'a') as f:
            f.write(url3 + '\n')

    print("Sleeping for 10 secs")
    time.sleep(10)






# Extras :
# with open("response.txt",'w') as f:
# 	f.write(soup.prettify())
#
# print(soup.prettify())
#
# print(str(response1))




# Note:
# query = 'inurl:wp-content/%20after:2020-05-02&start=1'
# inurl:wp-content/%20after:2020-05-02&start=1

# Use string slicing syntax string[n:] with n as the amount of characters to remove the first n characters from a string.

# \